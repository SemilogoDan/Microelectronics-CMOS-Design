README
The relevant  files  for  the  sawtooth waveform  generation  are  included  and  the  pdf  for  the  project  instruction is  included.  Inspiration  mainly from the  lecture  on comparator, Upfront_essential and  the  CMOS  basics lecture.
Accuracy  is  within  a few  % of  say 10%.